const config = {
  API_URL: 'https://blog.hk.tlu.ee',
  // API_URL: 'http://localhost:3000',
};

export default config;
