# Kaheksanda loengu kood
