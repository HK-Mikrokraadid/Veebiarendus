const config = {
  jwtSecret: 'secret-password',
  db: {
    database: 'todos',
    user: 'mrt',
    password: '',
    port: 3306,
    connectTimeout: 5000, // timeout, kui andmebaasiga ühendust ei saa
  },
};

module.exports = config;
