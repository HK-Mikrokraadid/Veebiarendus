const config = {
  jwtSecret: 'very-secret-password',
  db: {
    database: 'todos',
    user: 'mrt',
    password: 'secret',
    port: 3306,
  },
};

module.exports = config;
