const config = {
  jwtSecret: 'secret-password',
  db: {
    database: 'database',
    user: 'user',
    password: 'password',
    port: 3306,
  },
};

module.exports = config;
