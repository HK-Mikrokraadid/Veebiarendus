# Kaheksanda loengu kood
