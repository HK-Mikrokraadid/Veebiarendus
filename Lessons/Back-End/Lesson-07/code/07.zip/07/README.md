# Seitsmenda loengu kood
