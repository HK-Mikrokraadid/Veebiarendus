const users = [
  {
    id: 1,
    firstName: 'Admin',
    lastName: 'Admin',
    email: 'admin@admin.ee',
    password: '$2b$10$YtX0jAxzwouT37mydNHwjOs5.qzc.s5lrMMYrOHZgVosal1bYpXBC',
    role: 'admin',
  },
  {
    id: 2,
    firstName: 'User',
    lastName: 'User',
    email: 'user@user.ee',
    password: '$2b$10$J7xTk5m97yK4agISAYBTxe2VVVVM6rP7kEhl679IW8/OBYYRCl/sq',
    role: 'user',
  },
];

module.exports = users;
