const config = {
  jwtSecret: 'very-secret-password',
};

module.exports = config;
